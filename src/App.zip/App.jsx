import { Routes, Route } from "react-router-dom";

import Navbar from "./components/navbar.jsx";
import HeroSection from "./features/herosection.jsx";
import StatsSection from "./features/statsSection.jsx";
import CategorySection from "./components/CategorySection.jsx";

import ProductGrid from "./components/ProductGrid.jsx";
import ProductDetails from "./pages/ProductDetails.jsx";
import LogIn from "./pages/logIn.jsx";

import "./styles/navbar.css";
import "./styles/hero.css";
import "./styles/searchbar.css";
import "./styles/stats.css";
import "./styles/category.css";
import "./styles/product.css";
import "./styles/productDetails.css";

export default function App() {
  return (
    <div>
      <Navbar />

      <Routes>
        {/* 🏠 HOME PAGE */}
        <Route
          path="/"
          element={
            <>
              <HeroSection />
              <StatsSection />
              <CategorySection />
              <ProductGrid />
              <logIn />
            </>
          }
        />

        {/* 📄 PRODUCT DETAILS PAGE */}
        <Route path="/product/:id" element={<ProductDetails />} />
      </Routes>
    </div>
  );
}
